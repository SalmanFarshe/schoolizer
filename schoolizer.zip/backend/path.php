<?php
// Dynamically define the base URL for localhost
    define('BASE_URL', 'http://localhost/' . basename(dirname(__DIR__)) . '/');
?>